
@role_required('BUY')
def view_shopping_cart(request):
    """
    Retrieve and display the items in the user's shopping cart.
    """
    # Get the current user's shopping cart from the session.
    shopping_cart = request.session.get('shopping_cart', {})

    # Retrieve the products from the shopping cart based on their IDs.
    products = Product.objects.filter(id__in=shopping_cart.keys())

    # Calculate the total cost of the products in the cart.
    total_cost = sum(product.price * quantity for product,
                     quantity in shopping_cart.items())

    # Render the template with the shopping cart items.
    return render(request, 'products/shopping-cart.html', {
        'products': products,
        'total_cost': total_cost
    })


@role_required('BUY')
def remove_product(request, prd_id):
    """
    Remove a product from the user's shopping cart based on the provided product ID.
    """
    # Get the current user's shopping cart from the session.
    shopping_cart = request.session.get('shopping_cart', {})

    # Remove the product from the shopping cart if it exists.
    if prd_id in shopping_cart:
        del shopping_cart[prd_id]

    # Show a success message to the user.
    messages.success(request, f'Product removed from cart: {
                     Product.objects.get(id=prd_id).name}')

    # Redirect to the shopping cart page.
    return redirect('products:cart')


@role_required('BUY')
def checkout(request):
    """
    Process the checkout of the user's shopping cart.
    """
    # Get the current user's shopping cart from the session.
    shopping_cart = request.session.get('shopping_cart', {})

    # Retrieve the products from the shopping cart based on their IDs.
    products = Product.objects.filter(id__in=shopping_cart.keys())

    # Calculate the total cost of the products in the cart.
    total_cost = sum(product.price * quantity for product,
                     quantity in shopping_cart.items())

    # Render the template with the checkout form.
    return render(request, 'products/checkout.html', {
        'products': products,
        'total_cost': total_cost
    })


@role_required('BUY')
def place_order(request):
    """
    Place the order for the user's shopping cart.
    """
    # Get the current user's shopping cart from the session.
    shopping_cart = request.session.get('shopping_cart', {})

    # Retrieve the products from the shopping cart based on their IDs.
    products = Product.objects.filter(id__in=shopping_cart.keys())

    # Calculate the total cost of the products in the cart.
    total_cost = sum(product.price * quantity for product,
                     quantity in shopping_cart.items())

    # Create a new Order object for the current user.
    order = Order(user=request.user)
    order.save()

    # Create a new OrderItem object for each product in the shopping cart.
    for product_id, quantity in shopping_cart.items():
        product = Product.objects.get(id=product_id)
        order_item = OrderItem(order=order, product=product, quantity=quantity)
        order_item.save()

    # Clear the shopping cart from the session.
    del request.session['shopping_cart']

    # Show a success message to the user.
    messages.success(request, 'Order placed successfully')

    # Redirect to the order details page.
    return redirect('products:order_detail', order_id=order.id)
